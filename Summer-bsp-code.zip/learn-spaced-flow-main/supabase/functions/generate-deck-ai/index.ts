import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.53.0';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { prompt, deckName, deckDescription } = await req.json();
    
    console.log('Generating deck with AI for prompt:', prompt);

    const openAIApiKey = Deno.env.get('OPENAI_API_KEY');
    if (!openAIApiKey) {
      throw new Error('OpenAI API key not configured');
    }

    // Create Supabase client
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_ANON_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    // Generate flashcards using OpenAI
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${openAIApiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-4.1-2025-04-14',
        messages: [
          {
            role: 'system',
            content: `You are a flashcard generator. Create educational flashcards based on the user's prompt. 
            Return ONLY a valid JSON array of flashcard objects with this exact structure:
            [
              {
                "front": "Question or term",
                "back": "Answer or definition",
                "example": "Optional example sentence or context"
              }
            ]
            
            Generate 10-15 high-quality flashcards. Make sure the JSON is valid and properly formatted.
            Do not include any explanation or additional text, just the JSON array.`
          },
          {
            role: 'user',
            content: prompt
          }
        ],
        max_completion_tokens: 2000
      }),
    });

    if (!response.ok) {
      const errorData = await response.text();
      console.error('OpenAI API error:', errorData);
      throw new Error(`OpenAI API error: ${response.status}`);
    }

    const data = await response.json();
    const generatedContent = data.choices[0].message.content;
    console.log('Generated content:', generatedContent);

    // Parse the generated flashcards
    let flashcards;
    try {
      flashcards = JSON.parse(generatedContent);
    } catch (parseError) {
      console.error('Failed to parse OpenAI response:', parseError);
      throw new Error('Failed to parse AI-generated flashcards');
    }

    if (!Array.isArray(flashcards)) {
      throw new Error('AI did not return a valid array of flashcards');
    }

    // Create the deck
    const { data: deck, error: deckError } = await supabase
      .from('decks')
      .insert({
        name: deckName || `AI Generated: ${prompt.substring(0, 50)}...`,
        description: deckDescription || `Flashcards generated from: ${prompt}`,
        user_id: '00000000-0000-0000-0000-000000000000' // Default user for demo
      })
      .select()
      .single();

    if (deckError) {
      console.error('Error creating deck:', deckError);
      throw new Error('Failed to create deck');
    }

    console.log('Created deck:', deck);

    // Insert the flashcards
    const cardsToInsert = flashcards.map((card: any) => ({
      deck_id: deck.id,
      front: card.front || '',
      back: card.back || '',
      example: card.example || null,
      card_type: 'basic'
    }));

    const { data: cards, error: cardsError } = await supabase
      .from('cards')
      .insert(cardsToInsert)
      .select();

    if (cardsError) {
      console.error('Error creating cards:', cardsError);
      throw new Error('Failed to create flashcards');
    }

    console.log(`Created ${cards.length} cards for deck ${deck.id}`);

    return new Response(JSON.stringify({ 
      deck,
      cards,
      message: `Successfully generated ${cards.length} flashcards!`
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('Error in generate-deck-ai function:', error);
    return new Response(JSON.stringify({ 
      error: error.message || 'An unexpected error occurred' 
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});