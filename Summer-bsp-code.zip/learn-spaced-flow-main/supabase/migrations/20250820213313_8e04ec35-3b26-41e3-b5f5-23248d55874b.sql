-- Fix security warnings by setting search_path for functions

-- Fix update_updated_at_column function
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER 
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

-- Fix update_study_goals_updated_at function  
CREATE OR REPLACE FUNCTION public.update_study_goals_updated_at()
RETURNS TRIGGER 
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

-- Fix calculate_card_difficulty function
CREATE OR REPLACE FUNCTION public.calculate_card_difficulty(card_uuid UUID)
RETURNS VOID 
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  total_count INTEGER;
  correct_count INTEGER;
  avg_time INTEGER;
  difficulty NUMERIC;
BEGIN
  -- Get review statistics
  SELECT 
    COUNT(*),
    COUNT(*) FILTER (WHERE rating >= 3),
    AVG(response_time_ms)::INTEGER
  INTO total_count, correct_count, avg_time
  FROM public.review_records 
  WHERE card_id = card_uuid;
  
  -- Calculate difficulty score (0.0 = easy, 1.0 = hard)
  IF total_count = 0 THEN
    difficulty := 0.5; -- Default for new cards
  ELSE
    difficulty := 1.0 - (correct_count::NUMERIC / total_count::NUMERIC);
  END IF;
  
  -- Insert or update difficulty record
  INSERT INTO public.card_difficulty (card_id, difficulty_score, total_reviews, correct_reviews, average_response_time)
  VALUES (card_uuid, difficulty, total_count, correct_count, COALESCE(avg_time, 0))
  ON CONFLICT (card_id) 
  DO UPDATE SET 
    difficulty_score = difficulty,
    total_reviews = total_count,
    correct_reviews = correct_count,
    average_response_time = COALESCE(avg_time, 0),
    last_calculated = now();
END;
$$;