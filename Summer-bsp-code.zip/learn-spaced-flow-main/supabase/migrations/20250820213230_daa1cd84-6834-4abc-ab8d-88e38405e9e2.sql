-- Add spaced repetition and study session tracking tables

-- Study sessions table
CREATE TABLE public.study_sessions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  deck_id UUID REFERENCES public.decks(id) ON DELETE CASCADE,
  started_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  ended_at TIMESTAMP WITH TIME ZONE,
  cards_studied INTEGER DEFAULT 0,
  cards_correct INTEGER DEFAULT 0,
  session_type TEXT DEFAULT 'regular', -- 'regular', 'review', 'cram'
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Study goals table
CREATE TABLE public.study_goals (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  goal_type TEXT NOT NULL, -- 'daily_cards', 'daily_time', 'streak'
  target_value INTEGER NOT NULL,
  current_value INTEGER DEFAULT 0,
  target_date DATE,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Card tags for organization
CREATE TABLE public.card_tags (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  color TEXT DEFAULT '#3B82F6',
  user_id UUID NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Junction table for card-tag relationships
CREATE TABLE public.card_tag_relations (
  card_id UUID REFERENCES public.cards(id) ON DELETE CASCADE,
  tag_id UUID REFERENCES public.card_tags(id) ON DELETE CASCADE,
  PRIMARY KEY (card_id, tag_id)
);

-- Enhanced review records with more tracking
ALTER TABLE public.review_records 
ADD COLUMN session_id UUID REFERENCES public.study_sessions(id) ON DELETE SET NULL,
ADD COLUMN response_time_ms INTEGER,
ADD COLUMN previous_rating INTEGER,
ADD COLUMN consecutive_correct INTEGER DEFAULT 0;

-- Card difficulty tracking
CREATE TABLE public.card_difficulty (
  card_id UUID REFERENCES public.cards(id) ON DELETE CASCADE PRIMARY KEY,
  difficulty_score NUMERIC DEFAULT 0.5, -- 0.0 (easy) to 1.0 (hard)
  total_reviews INTEGER DEFAULT 0,
  correct_reviews INTEGER DEFAULT 0,
  average_response_time INTEGER DEFAULT 0,
  last_calculated TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Multiple choice options for cards
CREATE TABLE public.card_options (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  card_id UUID REFERENCES public.cards(id) ON DELETE CASCADE,
  option_text TEXT NOT NULL,
  is_correct BOOLEAN DEFAULT false,
  order_position INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Add new columns to cards table for enhanced features
ALTER TABLE public.cards 
ADD COLUMN card_type TEXT DEFAULT 'basic', -- 'basic', 'multiple_choice', 'cloze'
ADD COLUMN audio_url TEXT,
ADD COLUMN image_url TEXT,
ADD COLUMN difficulty_level INTEGER DEFAULT 1, -- 1-5 scale
ADD COLUMN times_reviewed INTEGER DEFAULT 0,
ADD COLUMN last_reviewed TIMESTAMP WITH TIME ZONE;

-- Enable RLS on all new tables
ALTER TABLE public.study_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.study_goals ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.card_tags ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.card_tag_relations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.card_difficulty ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.card_options ENABLE ROW LEVEL SECURITY;

-- Create RLS policies for all tables
CREATE POLICY "Users can manage their own study sessions" 
ON public.study_sessions FOR ALL USING (true);

CREATE POLICY "Users can manage their own study goals" 
ON public.study_goals FOR ALL USING (true);

CREATE POLICY "Users can manage their own card tags" 
ON public.card_tags FOR ALL USING (true);

CREATE POLICY "Users can manage card tag relations" 
ON public.card_tag_relations FOR ALL USING (true);

CREATE POLICY "Users can view card difficulty" 
ON public.card_difficulty FOR ALL USING (true);

CREATE POLICY "Users can manage card options" 
ON public.card_options FOR ALL USING (true);

-- Create indexes for better performance
CREATE INDEX idx_study_sessions_user_id ON public.study_sessions(user_id);
CREATE INDEX idx_study_sessions_deck_id ON public.study_sessions(deck_id);
CREATE INDEX idx_study_goals_user_id ON public.study_goals(user_id);
CREATE INDEX idx_card_tags_user_id ON public.card_tags(user_id);
CREATE INDEX idx_card_difficulty_card_id ON public.card_difficulty(card_id);
CREATE INDEX idx_card_options_card_id ON public.card_options(card_id);
CREATE INDEX idx_review_records_session_id ON public.review_records(session_id);

-- Trigger for updating study goals
CREATE OR REPLACE FUNCTION public.update_study_goals_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_study_goals_updated_at
BEFORE UPDATE ON public.study_goals
FOR EACH ROW
EXECUTE FUNCTION public.update_study_goals_updated_at();

-- Function to calculate card difficulty
CREATE OR REPLACE FUNCTION public.calculate_card_difficulty(card_uuid UUID)
RETURNS VOID AS $$
DECLARE
  total_count INTEGER;
  correct_count INTEGER;
  avg_time INTEGER;
  difficulty NUMERIC;
BEGIN
  -- Get review statistics
  SELECT 
    COUNT(*),
    COUNT(*) FILTER (WHERE rating >= 3),
    AVG(response_time_ms)::INTEGER
  INTO total_count, correct_count, avg_time
  FROM public.review_records 
  WHERE card_id = card_uuid;
  
  -- Calculate difficulty score (0.0 = easy, 1.0 = hard)
  IF total_count = 0 THEN
    difficulty := 0.5; -- Default for new cards
  ELSE
    difficulty := 1.0 - (correct_count::NUMERIC / total_count::NUMERIC);
  END IF;
  
  -- Insert or update difficulty record
  INSERT INTO public.card_difficulty (card_id, difficulty_score, total_reviews, correct_reviews, average_response_time)
  VALUES (card_uuid, difficulty, total_count, correct_count, COALESCE(avg_time, 0))
  ON CONFLICT (card_id) 
  DO UPDATE SET 
    difficulty_score = difficulty,
    total_reviews = total_count,
    correct_reviews = correct_count,
    average_response_time = COALESCE(avg_time, 0),
    last_calculated = now();
END;
$$ LANGUAGE plpgsql;