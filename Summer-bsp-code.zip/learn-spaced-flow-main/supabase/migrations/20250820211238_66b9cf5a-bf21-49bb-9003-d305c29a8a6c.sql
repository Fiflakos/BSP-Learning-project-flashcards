-- Temporarily allow unauthenticated access for local development
-- Drop existing restrictive RLS policies
DROP POLICY IF EXISTS "Users can view their own decks" ON public.decks;
DROP POLICY IF EXISTS "Users can create their own decks" ON public.decks;
DROP POLICY IF EXISTS "Users can update their own decks" ON public.decks;
DROP POLICY IF EXISTS "Users can delete their own decks" ON public.decks;

DROP POLICY IF EXISTS "Users can view cards from their decks" ON public.cards;
DROP POLICY IF EXISTS "Users can create cards in their decks" ON public.cards;
DROP POLICY IF EXISTS "Users can update cards in their decks" ON public.cards;
DROP POLICY IF EXISTS "Users can delete cards from their decks" ON public.cards;

DROP POLICY IF EXISTS "Users can view their own review records" ON public.review_records;
DROP POLICY IF EXISTS "Users can create their own review records" ON public.review_records;
DROP POLICY IF EXISTS "Users can update their own review records" ON public.review_records;

-- Create permissive policies for local development (no auth required)
CREATE POLICY "Allow all access to decks" ON public.decks FOR ALL USING (true);
CREATE POLICY "Allow all access to cards" ON public.cards FOR ALL USING (true);  
CREATE POLICY "Allow all access to review_records" ON public.review_records FOR ALL USING (true);