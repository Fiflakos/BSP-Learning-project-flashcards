-- Create some sample study sessions and review records to populate the progress analytics

-- Insert sample study sessions for the last 14 days
INSERT INTO study_sessions (user_id, deck_id, cards_studied, cards_correct, started_at, ended_at, session_type) VALUES
('00000000-0000-0000-0000-000000000000', '550e8400-e29b-41d4-a716-446655440001', 15, 12, now() - interval '1 day', now() - interval '1 day' + interval '25 minutes', 'regular'),
('00000000-0000-0000-0000-000000000000', '550e8400-e29b-41d4-a716-446655440002', 20, 16, now() - interval '2 days', now() - interval '2 days' + interval '30 minutes', 'regular'),
('00000000-0000-0000-0000-000000000000', '550e8400-e29b-41d4-a716-446655440003', 18, 14, now() - interval '3 days', now() - interval '3 days' + interval '22 minutes', 'regular'),
('00000000-0000-0000-0000-000000000000', '550e8400-e29b-41d4-a716-446655440001', 25, 22, now() - interval '4 days', now() - interval '4 days' + interval '35 minutes', 'regular'),
('00000000-0000-0000-0000-000000000000', '550e8400-e29b-41d4-a716-446655440004', 12, 10, now() - interval '5 days', now() - interval '5 days' + interval '18 minutes', 'regular'),
('00000000-0000-0000-0000-000000000000', '550e8400-e29b-41d4-a716-446655440002', 22, 19, now() - interval '6 days', now() - interval '6 days' + interval '28 minutes', 'regular'),
('00000000-0000-0000-0000-000000000000', '550e8400-e29b-41d4-a716-446655440003', 16, 13, now() - interval '7 days', now() - interval '7 days' + interval '20 minutes', 'regular'),
('00000000-0000-0000-0000-000000000000', '550e8400-e29b-41d4-a716-446655440001', 30, 26, now() - interval '8 days', now() - interval '8 days' + interval '40 minutes', 'regular'),
('00000000-0000-0000-0000-000000000000', '550e8400-e29b-41d4-a716-446655440004', 14, 11, now() - interval '9 days', now() - interval '9 days' + interval '16 minutes', 'regular'),
('00000000-0000-0000-0000-000000000000', '550e8400-e29b-41d4-a716-446655440002', 19, 17, now() - interval '10 days', now() - interval '10 days' + interval '24 minutes', 'regular'),
('00000000-0000-0000-0000-000000000000', '550e8400-e29b-41d4-a716-446655440003', 21, 18, now() - interval '11 days', now() - interval '11 days' + interval '26 minutes', 'regular'),
('00000000-0000-0000-0000-000000000000', '550e8400-e29b-41d4-a716-446655440001', 17, 15, now() - interval '12 days', now() - interval '12 days' + interval '21 minutes', 'regular'),
('00000000-0000-0000-0000-000000000000', '550e8400-e29b-41d4-a716-446655440004', 23, 20, now() - interval '13 days', now() - interval '13 days' + interval '32 minutes', 'regular'),
('00000000-0000-0000-0000-000000000000', '550e8400-e29b-41d4-a716-446655440002', 13, 11, now() - interval '14 days', now() - interval '14 days' + interval '17 minutes', 'regular');

-- Insert sample review records for different ratings and time distribution
INSERT INTO review_records (user_id, card_id, rating, response_time_ms, ease_factor, interval_days, next_review_date, session_id) 
SELECT 
    '00000000-0000-0000-0000-000000000000',
    c.id,
    (ARRAY[1,2,3,4])[floor(random() * 4 + 1)],
    floor(random() * 5000 + 1000)::integer,
    2.5,
    1,
    now() + interval '1 day',
    null
FROM cards c 
WHERE c.deck_id IN ('550e8400-e29b-41d4-a716-446655440001', '550e8400-e29b-41d4-a716-446655440002', '550e8400-e29b-41d4-a716-446655440003', '550e8400-e29b-41d4-a716-446655440004')
LIMIT 50;

-- Create card difficulty records for some cards
INSERT INTO card_difficulty (card_id, difficulty_score, total_reviews, correct_reviews, average_response_time)
SELECT 
    c.id,
    random(),
    floor(random() * 20 + 5)::integer,
    floor(random() * 15 + 1)::integer,
    floor(random() * 3000 + 1500)::integer
FROM cards c 
WHERE c.deck_id IN ('550e8400-e29b-41d4-a716-446655440001', '550e8400-e29b-41d4-a716-446655440002', '550e8400-e29b-41d4-a716-446655440003', '550e8400-e29b-41d4-a716-446655440004')
LIMIT 30;