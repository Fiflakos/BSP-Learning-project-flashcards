# Flashcard Study App

## Getting Started

The only requirement is having Node.js & npm installed - [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating)

### Option 1: From GitHub Repository

Clone the repository and install dependencies to start developing locally.

```sh
# Step 1: Clone the repository using the project's Git URL.
git clone <YOUR_GIT_URL>

# Step 2: Navigate to the project directory.
cd <YOUR_PROJECT_NAME>

# Step 3: Install the necessary dependencies.
npm i

# Step 4: Set up environment variables.
cp .env.example .env
# Edit .env file with your Supabase credentials

# Step 5: Start the development server with auto-reloading and an instant preview.
npm run dev
```

### Option 2: From ZIP File

If you received the project as a ZIP file:

```sh
# Step 1: Extract the ZIP file to your desired location.
# (Use your operating system's built-in extraction tool)

# Step 2: Navigate to the extracted project directory.
cd flashcard-study-app

# Step 3: Install the necessary dependencies.
npm i

# Step 4: Create environment variables file.
# Create a new file called .env in the root directory
# Add your Supabase credentials (see Environment Variables section below)

# Step 5: Start the development server with auto-reloading and an instant preview.
npm run dev
```

## Environment Setup

### Prerequisites

- Node.js & npm - [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating)
- Supabase account (for backend functionality)

### Environment Variables

1. Copy the environment template:
   ```sh
   cp .env.example .env
   ```

2. Update the `.env` file with your Supabase credentials:
   ```
   VITE_SUPABASE_PROJECT_ID="your-project-id"
   VITE_SUPABASE_PUBLISHABLE_KEY="your-publishable-key"
   VITE_SUPABASE_URL="your-supabase-url"
   ```

3. Get your Supabase credentials:
   - Go to [Supabase Dashboard](https://supabase.com/dashboard)
   - Create a new project or select existing one
   - Go to Settings → API
   - Copy the Project URL, Project ID, and anon/public key

**Edit a file directly in GitHub**

- Navigate to the desired file(s).
- Click the "Edit" button (pencil icon) at the top right of the file view.
- Make your changes and commit the changes.

**Use GitHub Codespaces**

- Navigate to the main page of your repository.
- Click on the "Code" button (green button) near the top right.
- Select the "Codespaces" tab.
- Click on "New codespace" to launch a new Codespace environment.
- Edit files directly within the Codespace and commit and push your changes once you're done.

## What technologies are used for this project?

This project is built with:

- Vite
- TypeScript
- React
- shadcn-ui
- Tailwind CSS

## Deployment

Build the project using `npm run build` and deploy the `dist` folder to your preferred hosting platform.
