import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, ResponsiveContainer, Area, AreaChart } from "recharts";

const mockData = [
  { date: "Mon", studied: 45, mastered: 12 },
  { date: "Tue", studied: 32, mastered: 8 },
  { date: "Wed", studied: 58, mastered: 18 },
  { date: "Thu", studied: 41, mastered: 15 },
  { date: "Fri", studied: 67, mastered: 22 },
  { date: "Sat", studied: 38, mastered: 9 },
  { date: "Sun", studied: 29, mastered: 7 },
];

const ProgressChart = () => {
  return (
    <Card className="bg-gradient-card border-border/50">
      <CardHeader>
        <CardTitle className="text-foreground">Weekly Progress</CardTitle>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <AreaChart data={mockData}>
            <defs>
              <linearGradient id="studiedGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3}/>
                <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0}/>
              </linearGradient>
              <linearGradient id="masteredGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="hsl(var(--success))" stopOpacity={0.3}/>
                <stop offset="95%" stopColor="hsl(var(--success))" stopOpacity={0}/>
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
            <XAxis 
              dataKey="date" 
              stroke="hsl(var(--muted-foreground))"
              fontSize={12}
            />
            <YAxis 
              stroke="hsl(var(--muted-foreground))"
              fontSize={12}
            />
            <Area
              type="monotone"
              dataKey="studied"
              stroke="hsl(var(--primary))"
              fillOpacity={1}
              fill="url(#studiedGradient)"
              strokeWidth={2}
            />
            <Area
              type="monotone"
              dataKey="mastered"
              stroke="hsl(var(--success))"
              fillOpacity={1}
              fill="url(#masteredGradient)"
              strokeWidth={2}
            />
          </AreaChart>
        </ResponsiveContainer>
        <div className="flex items-center justify-center gap-6 mt-4">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-primary rounded-full"></div>
            <span className="text-sm text-muted-foreground">Cards Studied</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-success rounded-full"></div>
            <span className="text-sm text-muted-foreground">Cards Mastered</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default ProgressChart;