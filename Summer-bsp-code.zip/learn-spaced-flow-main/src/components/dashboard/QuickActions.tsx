import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Play, Plus, Download, Calendar, BookOpen, Target } from "lucide-react";
import { useNavigate } from "react-router-dom";

const QuickActions = () => {
  const navigate = useNavigate();
  
  const actions = [
    {
      icon: <Play className="w-5 h-5" />,
      title: "Start Study Session",
      description: "Continue where you left off",
      variant: "default" as const,
      className: "bg-gradient-primary text-white shadow-glow hover:shadow-card-hover"
    },
    {
      icon: <Plus className="w-5 h-5" />,
      title: "Create New Deck",
      description: "Build your custom flashcards",
      variant: "outline" as const,
      className: "border-primary text-primary hover:bg-primary hover:text-white"
    },
    {
      icon: <Download className="w-5 h-5" />,
      title: "Import Deck",
      description: "Upload from Anki or CSV",
      variant: "outline" as const,
      className: "border-accent text-accent hover:bg-accent hover:text-black"
    },
    {
      icon: <Calendar className="w-5 h-5" />,
      title: "View Schedule",
      description: "See upcoming reviews",
      variant: "ghost" as const,
      className: ""
    },
    {
      icon: <BookOpen className="w-5 h-5" />,
      title: "Browse Decks",
      description: "Manage your collections",
      variant: "ghost" as const,
      className: ""
    },
    {
      icon: <Target className="w-5 h-5" />,
      title: "Set Goals",
      description: "Track your progress",
      variant: "ghost" as const,
      className: ""
    }
  ];

  return (
    <Card className="bg-gradient-card border-border/50">
      <CardHeader>
        <CardTitle className="text-foreground">Quick Actions</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {actions.map((action, index) => (
            <Button
              key={index}
              variant={action.variant}
              className={`h-auto p-4 flex flex-col items-start gap-2 text-left ${action.className}`}
              onClick={() => {
                if (action.title === "Start Study Session") {
                  navigate("/study");
                } else if (action.title === "Browse Decks") {
                  navigate("/decks");
                } else if (action.title === "Create New Deck") {
                  navigate("/decks");
                }
              }}
            >
              <div className="flex items-center gap-2">
                {action.icon}
                <span className="font-semibold">{action.title}</span>
              </div>
              <span className="text-xs opacity-80 font-normal">
                {action.description}
              </span>
            </Button>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default QuickActions;