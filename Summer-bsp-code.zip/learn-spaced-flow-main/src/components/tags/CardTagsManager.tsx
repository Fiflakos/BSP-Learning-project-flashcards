import { useState, useEffect } from 'react';
import { Plus, Tag, Edit, Trash2, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface CardTag {
  id: string;
  name: string;
  color: string;
  created_at: string;
}

interface CardTagsManagerProps {
  cardId?: string;
  selectedTags?: string[];
  onTagsChange?: (tagIds: string[]) => void;
  showTagCreation?: boolean;
}

const DEFAULT_COLORS = [
  '#3B82F6', '#EF4444', '#10B981', '#F59E0B', 
  '#8B5CF6', '#EC4899', '#06B6D4', '#84CC16'
];

export const CardTagsManager = ({ 
  cardId, 
  selectedTags = [], 
  onTagsChange, 
  showTagCreation = true 
}: CardTagsManagerProps) => {
  const [tags, setTags] = useState<CardTag[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [newTag, setNewTag] = useState({ name: '', color: DEFAULT_COLORS[0] });
  const [localSelectedTags, setLocalSelectedTags] = useState<string[]>(selectedTags);

  useEffect(() => {
    fetchTags();
  }, []);

  useEffect(() => {
    setLocalSelectedTags(selectedTags);
  }, [selectedTags]);

  const fetchTags = async () => {
    try {
      const { data, error } = await supabase
        .from('card_tags')
        .select('*')
        .eq('user_id', 'temp-user-id') // TODO: Replace with actual user ID
        .order('name');

      if (error) throw error;
      setTags(data || []);
    } catch (error) {
      console.error('Error fetching tags:', error);
      toast.error('Failed to load tags');
    } finally {
      setLoading(false);
    }
  };

  const createTag = async () => {
    if (!newTag.name.trim()) {
      toast.error('Tag name is required');
      return;
    }

    try {
      const { data, error } = await supabase
        .from('card_tags')
        .insert({
          name: newTag.name.trim(),
          color: newTag.color,
          user_id: 'temp-user-id' // TODO: Replace with actual user ID
        })
        .select()
        .single();

      if (error) throw error;

      setTags(prev => [...prev, data]);
      setNewTag({ name: '', color: DEFAULT_COLORS[0] });
      setDialogOpen(false);
      toast.success('Tag created successfully!');
    } catch (error) {
      console.error('Error creating tag:', error);
      toast.error('Failed to create tag');
    }
  };

  const deleteTag = async (tagId: string) => {
    try {
      const { error } = await supabase
        .from('card_tags')
        .delete()
        .eq('id', tagId);

      if (error) throw error;

      setTags(prev => prev.filter(tag => tag.id !== tagId));
      setLocalSelectedTags(prev => prev.filter(id => id !== tagId));
      onTagsChange?.(localSelectedTags.filter(id => id !== tagId));
      toast.success('Tag deleted');
    } catch (error) {
      console.error('Error deleting tag:', error);
      toast.error('Failed to delete tag');
    }
  };

  const toggleTagSelection = (tagId: string) => {
    const newSelection = localSelectedTags.includes(tagId)
      ? localSelectedTags.filter(id => id !== tagId)
      : [...localSelectedTags, tagId];
    
    setLocalSelectedTags(newSelection);
    onTagsChange?.(newSelection);
  };

  const saveCardTags = async () => {
    if (!cardId) return;

    try {
      // Remove existing tag relations
      await supabase
        .from('card_tag_relations')
        .delete()
        .eq('card_id', cardId);

      // Add new tag relations
      if (localSelectedTags.length > 0) {
        const relations = localSelectedTags.map(tagId => ({
          card_id: cardId,
          tag_id: tagId
        }));

        const { error } = await supabase
          .from('card_tag_relations')
          .insert(relations);

        if (error) throw error;
      }

      toast.success('Card tags updated!');
    } catch (error) {
      console.error('Error saving card tags:', error);
      toast.error('Failed to save card tags');
    }
  };

  if (loading) {
    return <div className="animate-pulse h-20 bg-muted rounded"></div>;
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <Label className="text-sm font-medium">Tags</Label>
        {showTagCreation && (
          <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="outline" size="sm">
                <Plus className="w-4 h-4 mr-2" />
                Create Tag
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Create New Tag</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="tag-name">Tag Name</Label>
                  <Input
                    id="tag-name"
                    value={newTag.name}
                    onChange={(e) => setNewTag({ ...newTag, name: e.target.value })}
                    placeholder="Enter tag name"
                  />
                </div>
                <div>
                  <Label>Color</Label>
                  <div className="flex gap-2 mt-2">
                    {DEFAULT_COLORS.map(color => (
                      <button
                        key={color}
                        className={`w-8 h-8 rounded-full border-2 ${
                          newTag.color === color ? 'border-foreground' : 'border-transparent'
                        }`}
                        style={{ backgroundColor: color }}
                        onClick={() => setNewTag({ ...newTag, color })}
                      />
                    ))}
                  </div>
                </div>
                <Button onClick={createTag} className="w-full">
                  Create Tag
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        )}
      </div>

      <div className="flex flex-wrap gap-2">
        {tags.map(tag => (
          <div key={tag.id} className="relative group">
            <Badge
              variant={localSelectedTags.includes(tag.id) ? "default" : "outline"}
              className="cursor-pointer pr-8 transition-colors"
              style={{
                backgroundColor: localSelectedTags.includes(tag.id) ? tag.color : 'transparent',
                borderColor: tag.color,
                color: localSelectedTags.includes(tag.id) ? 'white' : tag.color
              }}
              onClick={() => toggleTagSelection(tag.id)}
            >
              <Tag className="w-3 h-3 mr-1" />
              {tag.name}
            </Badge>
            {showTagCreation && (
              <Button
                variant="ghost"
                size="sm"
                className="absolute -top-1 -right-1 h-5 w-5 p-0 opacity-0 group-hover:opacity-100 transition-opacity bg-destructive hover:bg-destructive/80 text-destructive-foreground rounded-full"
                onClick={(e) => {
                  e.stopPropagation();
                  deleteTag(tag.id);
                }}
              >
                <X className="w-3 h-3" />
              </Button>
            )}
          </div>
        ))}
      </div>

      {tags.length === 0 && (
        <div className="text-center py-6 text-muted-foreground">
          <Tag className="w-8 h-8 mx-auto mb-2" />
          <p className="text-sm">No tags created yet</p>
          {showTagCreation && (
            <p className="text-xs">Create your first tag to organize your cards!</p>
          )}
        </div>
      )}

      {cardId && localSelectedTags.length > 0 && (
        <Button onClick={saveCardTags} size="sm" className="w-full">
          Save Tags to Card
        </Button>
      )}
    </div>
  );
};