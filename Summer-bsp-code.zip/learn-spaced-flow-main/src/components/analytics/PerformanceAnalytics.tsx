import { useState, useEffect } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell } from 'recharts';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { TrendingUp, TrendingDown, Clock, Target, Zap, Brain, Flame } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface PerformanceData {
  studySessions: any[];
  cardDifficulty: any[];
  reviewStats: any[];
  timeDistribution: any[];
}

interface StudyStreak {
  current: number;
  longest: number;
  lastStudyDate: string | null;
}

export const PerformanceAnalytics = () => {
  const [data, setData] = useState<PerformanceData>({
    studySessions: [],
    cardDifficulty: [],
    reviewStats: [],
    timeDistribution: []
  });
  const [streak, setStreak] = useState<StudyStreak>({ current: 0, longest: 0, lastStudyDate: null });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchAnalyticsData();
  }, []);

  const fetchAnalyticsData = async () => {
    try {
      // Fetch study sessions data (remove user filtering for now)
      const { data: sessionsData, error: sessionsError } = await supabase
        .from('study_sessions')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(30);

      if (sessionsError) throw sessionsError;

      // Fetch card difficulty data
      const { data: difficultyData, error: difficultyError } = await supabase
        .from('card_difficulty')
        .select(`
          *,
          cards!inner(front, deck_id, decks!inner(name))
        `)
        .order('difficulty_score', { ascending: false })
        .limit(20);

      if (difficultyError) throw difficultyError;

      // Fetch review statistics (remove user filtering for now)
      const { data: reviewData, error: reviewError } = await supabase
        .from('review_records')
        .select('rating, response_time_ms, created_at')
        .order('created_at', { ascending: false })
        .limit(100);

      if (reviewError) throw reviewError;

      // Process data for charts
      const processedData = {
        studySessions: processSessionsData(sessionsData || []),
        cardDifficulty: difficultyData || [],
        reviewStats: processReviewStats(reviewData || []),
        timeDistribution: processTimeDistribution(reviewData || [])
      };

      setData(processedData);
      setStreak(calculateStreak(sessionsData || []));
    } catch (error) {
      console.error('Error fetching analytics data:', error);
      toast.error('Failed to load analytics data');
    } finally {
      setLoading(false);
    }
  };

  const processSessionsData = (sessions: any[]) => {
    const dailyData: { [key: string]: { date: string; cards: number; accuracy: number; time: number } } = {};
    
    sessions.forEach(session => {
      const date = new Date(session.created_at).toLocaleDateString();
      if (!dailyData[date]) {
        dailyData[date] = { date, cards: 0, accuracy: 0, time: 0 };
      }
      dailyData[date].cards += session.cards_studied || 0;
      dailyData[date].accuracy += session.cards_correct / Math.max(1, session.cards_studied) * 100;
      dailyData[date].time += session.ended_at ? 
        (new Date(session.ended_at).getTime() - new Date(session.started_at).getTime()) / 60000 : 0;
    });

    return Object.values(dailyData).slice(0, 14).reverse();
  };

  const processReviewStats = (reviews: any[]) => {
    const ratingCounts = { 1: 0, 2: 0, 3: 0, 4: 0 };
    reviews.forEach(review => {
      ratingCounts[review.rating as keyof typeof ratingCounts]++;
    });

    return [
      { rating: 'Again', count: ratingCounts[1], color: '#ef4444' },
      { rating: 'Hard', count: ratingCounts[2], color: '#f97316' },
      { rating: 'Good', count: ratingCounts[3], color: '#22c55e' },
      { rating: 'Easy', count: ratingCounts[4], color: '#3b82f6' }
    ];
  };

  const processTimeDistribution = (reviews: any[]) => {
    const hourCounts: { [key: number]: number } = {};
    
    reviews.forEach(review => {
      const hour = new Date(review.created_at).getHours();
      hourCounts[hour] = (hourCounts[hour] || 0) + 1;
    });

    return Object.entries(hourCounts).map(([hour, count]) => ({
      hour: `${hour}:00`,
      count
    })).sort((a, b) => parseInt(a.hour) - parseInt(b.hour));
  };

  const calculateStreak = (sessions: any[]): StudyStreak => {
    if (sessions.length === 0) return { current: 0, longest: 0, lastStudyDate: null };

    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const sessionDates = sessions
      .map(s => {
        const date = new Date(s.created_at);
        date.setHours(0, 0, 0, 0);
        return date.getTime();
      })
      .filter((date, index, array) => array.indexOf(date) === index)
      .sort((a, b) => b - a);

    let currentStreak = 0;
    let longestStreak = 0;
    let tempStreak = 0;
    
    // Calculate current streak
    const todayTime = today.getTime();
    const yesterdayTime = todayTime - 24 * 60 * 60 * 1000;
    
    if (sessionDates.includes(todayTime)) {
      currentStreak = 1;
      let checkDate = yesterdayTime;
      while (sessionDates.includes(checkDate)) {
        currentStreak++;
        checkDate -= 24 * 60 * 60 * 1000;
      }
    } else if (sessionDates.includes(yesterdayTime)) {
      currentStreak = 1;
      let checkDate = yesterdayTime - 24 * 60 * 60 * 1000;
      while (sessionDates.includes(checkDate)) {
        currentStreak++;
        checkDate -= 24 * 60 * 60 * 1000;
      }
    }

    // Calculate longest streak
    for (let i = 0; i < sessionDates.length; i++) {
      if (i === 0 || sessionDates[i-1] - sessionDates[i] === 24 * 60 * 60 * 1000) {
        tempStreak++;
      } else {
        longestStreak = Math.max(longestStreak, tempStreak);
        tempStreak = 1;
      }
    }
    longestStreak = Math.max(longestStreak, tempStreak);

    return {
      current: currentStreak,
      longest: longestStreak,
      lastStudyDate: sessions[0]?.created_at || null
    };
  };

  if (loading) {
    return (
      <div className="space-y-6">
        {[1, 2, 3, 4].map((i) => (
          <Card key={i} className="animate-pulse">
            <CardHeader>
              <div className="h-6 bg-muted rounded w-1/3"></div>
            </CardHeader>
            <CardContent>
              <div className="h-32 bg-muted rounded"></div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  const averageAccuracy = data.studySessions.reduce((acc, session) => acc + (session.accuracy || 0), 0) / Math.max(1, data.studySessions.length);
  const totalCards = data.studySessions.reduce((acc, session) => acc + session.cards, 0);
  const averageResponseTime = data.reviewStats.reduce((acc, stat) => acc + stat.count, 0) > 0 ? 
    data.timeDistribution.reduce((acc, item) => acc + item.count, 0) / data.timeDistribution.length : 0;

  return (
    <div className="space-y-6">
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Study Streak</CardTitle>
            <Flame className="h-4 w-4 text-orange-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{streak.current} days</div>
            <p className="text-xs text-muted-foreground">
              Longest: {streak.longest} days
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Average Accuracy</CardTitle>
            <Target className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{averageAccuracy.toFixed(1)}%</div>
            <div className="flex items-center text-xs text-muted-foreground">
              {averageAccuracy >= 80 ? (
                <TrendingUp className="h-3 w-3 mr-1 text-green-500" />
              ) : (
                <TrendingDown className="h-3 w-3 mr-1 text-red-500" />
              )}
              {averageAccuracy >= 80 ? 'Excellent!' : 'Keep practicing!'}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Cards Studied</CardTitle>
            <Brain className="h-4 w-4 text-blue-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalCards}</div>
            <p className="text-xs text-muted-foreground">
              Last 14 days
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Avg Response Time</CardTitle>
            <Clock className="h-4 w-4 text-purple-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{averageResponseTime.toFixed(1)}s</div>
            <p className="text-xs text-muted-foreground">
              Per card
            </p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="progress" className="space-y-4">
        <TabsList>
          <TabsTrigger value="progress">Study Progress</TabsTrigger>
          <TabsTrigger value="difficulty">Card Difficulty</TabsTrigger>
          <TabsTrigger value="ratings">Review Ratings</TabsTrigger>
          <TabsTrigger value="timing">Study Timing</TabsTrigger>
        </TabsList>

        <TabsContent value="progress" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Daily Study Progress</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={data.studySessions}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis />
                  <Tooltip />
                  <Line type="monotone" dataKey="cards" stroke="#3b82f6" strokeWidth={2} />
                  <Line type="monotone" dataKey="accuracy" stroke="#22c55e" strokeWidth={2} />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="difficulty" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Most Difficult Cards</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {data.cardDifficulty.slice(0, 10).map((card, index) => (
                  <div key={card.card_id} className="flex items-center justify-between p-3 rounded-lg border">
                    <div className="flex-1">
                      <p className="font-medium">{card.cards?.front}</p>
                      <p className="text-sm text-muted-foreground">
                        {card.cards?.decks?.name} • {card.total_reviews} reviews
                      </p>
                    </div>
                    <Badge variant={card.difficulty_score > 0.7 ? "destructive" : card.difficulty_score > 0.4 ? "secondary" : "default"}>
                      {(card.difficulty_score * 100).toFixed(0)}% difficulty
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="ratings" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Review Ratings Distribution</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={data.reviewStats}
                    cx="50%"
                    cy="50%"
                    outerRadius={80}
                    dataKey="count"
                    label={({ rating, count }) => `${rating}: ${count}`}
                  >
                    {data.reviewStats.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="timing" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Study Time Distribution</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={data.timeDistribution}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="hour" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="count" fill="#3b82f6" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default PerformanceAnalytics;