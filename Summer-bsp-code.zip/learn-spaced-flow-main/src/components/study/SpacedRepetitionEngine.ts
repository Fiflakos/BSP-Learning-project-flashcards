export interface ReviewResult {
  cardId: string;
  rating: number;
  responseTime: number;
}

export interface CardSchedule {
  nextReviewDate: Date;
  interval: number;
  easeFactor: number;
  consecutiveCorrect: number;
}

export class SpacedRepetitionEngine {
  static calculateNextReview(
    previousEaseFactor: number = 2.5,
    previousInterval: number = 1,
    consecutiveCorrect: number = 0,
    rating: number
  ): CardSchedule {
    let easeFactor = previousEaseFactor;
    let interval = previousInterval;
    let newConsecutiveCorrect = consecutiveCorrect;

    if (rating >= 3) {
      newConsecutiveCorrect += 1;
      easeFactor = Math.max(1.3, easeFactor + (0.1 - (5 - rating) * (0.08 + (5 - rating) * 0.02)));
    } else {
      newConsecutiveCorrect = 0;
      easeFactor = Math.max(1.3, easeFactor - 0.2);
    }

    if (newConsecutiveCorrect === 1) {
      interval = 1;
    } else if (newConsecutiveCorrect === 2) {
      interval = 6;
    } else if (newConsecutiveCorrect > 2) {
      interval = Math.round(interval * easeFactor);
    } else {
      interval = 1;
    }

    if (rating === 1) {
      interval = 0;
    }

    const nextReviewDate = new Date();
    if (interval > 0) {
      nextReviewDate.setDate(nextReviewDate.getDate() + interval);
    } else {
      nextReviewDate.setMinutes(nextReviewDate.getMinutes() + 10);
    }

    return {
      nextReviewDate,
      interval,
      easeFactor: Math.round(easeFactor * 100) / 100,
      consecutiveCorrect: newConsecutiveCorrect
    };
  }

  static getDueCards(cards: any[]): any[] {
    const now = new Date();
    return cards.filter(card => {
      if (!card.next_review_date) return true;
      return new Date(card.next_review_date) <= now;
    });
  }

  static prioritizeCards(cards: any[]): any[] {
    return cards.sort((a, b) => {
      const now = new Date();
      const aNextReview = a.next_review_date ? new Date(a.next_review_date) : null;
      const bNextReview = b.next_review_date ? new Date(b.next_review_date) : null;
      
      if (!aNextReview && !bNextReview) return 0;
      if (!aNextReview) return 1;
      if (!bNextReview) return -1;
      
      const aOverdue = Math.max(0, now.getTime() - aNextReview.getTime());
      const bOverdue = Math.max(0, now.getTime() - bNextReview.getTime());
      
      return bOverdue - aOverdue;
    });
  }
}