import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { RotateCcw, Volume2, Image, Eye, EyeOff } from "lucide-react";
import { cn } from "@/lib/utils";

interface StudyCardProps {
  front: string;
  back: string;
  example?: string;
  hasAudio?: boolean;
  hasImage?: boolean;
  onRate: (difficulty: 'again' | 'hard' | 'good' | 'easy') => void;
}

const StudyCard = ({ front, back, example, hasAudio, hasImage, onRate }: StudyCardProps) => {
  const [isFlipped, setIsFlipped] = useState(false);
  const [showExample, setShowExample] = useState(false);

  const handleFlip = () => {
    setIsFlipped(!isFlipped);
  };

  const handleRate = (difficulty: 'again' | 'hard' | 'good' | 'easy') => {
    onRate(difficulty);
    setIsFlipped(false);
    setShowExample(false);
  };

  return (
    <div className="w-full max-w-2xl mx-auto">
      <Card 
        className={cn(
          "min-h-[400px] bg-gradient-card border-border/50 shadow-card cursor-pointer",
          "transition-all duration-300 hover:shadow-card-hover",
          isFlipped && "animate-card-flip"
        )}
        onClick={!isFlipped ? handleFlip : undefined}
      >
        <CardContent className="p-8 h-full flex flex-col justify-center items-center text-center space-y-6">
          {!isFlipped ? (
            // Front of card
            <>
              <div className="space-y-4">
                <h2 className="text-2xl font-bold text-foreground">{front}</h2>
                <div className="flex items-center justify-center gap-3">
                  {hasAudio && (
                    <Button variant="ghost" size="icon" className="text-primary">
                      <Volume2 className="w-5 h-5" />
                    </Button>
                  )}
                  {hasImage && (
                    <Button variant="ghost" size="icon" className="text-primary">
                      <Image className="w-5 h-5" />
                    </Button>
                  )}
                </div>
              </div>
              <p className="text-muted-foreground">Click to reveal answer</p>
            </>
          ) : (
            // Back of card
            <>
              <div className="space-y-4">
                <div className="text-sm text-muted-foreground">{front}</div>
                <h2 className="text-2xl font-bold text-foreground">{back}</h2>
                
                {example && (
                  <div className="space-y-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={(e) => {
                        e.stopPropagation();
                        setShowExample(!showExample);
                      }}
                      className="text-accent"
                    >
                      {showExample ? <EyeOff className="w-4 h-4 mr-2" /> : <Eye className="w-4 h-4 mr-2" />}
                      Example
                    </Button>
                    {showExample && (
                      <p className="text-muted-foreground italic border-l-2 border-accent pl-4">
                        {example}
                      </p>
                    )}
                  </div>
                )}
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-3 w-full max-w-md">
                <Button
                  variant="outline"
                  onClick={() => handleRate('again')}
                  className="border-destructive text-destructive hover:bg-destructive hover:text-destructive-foreground"
                >
                  Again
                </Button>
                <Button
                  variant="outline"
                  onClick={() => handleRate('hard')}
                  className="border-warning text-warning hover:bg-warning hover:text-warning-foreground"
                >
                  Hard
                </Button>
                <Button
                  variant="outline"
                  onClick={() => handleRate('good')}
                  className="border-primary text-primary hover:bg-primary hover:text-primary-foreground"
                >
                  Good
                </Button>
                <Button
                  variant="outline"
                  onClick={() => handleRate('easy')}
                  className="border-success text-success hover:bg-success hover:text-success-foreground"
                >
                  Easy
                </Button>
              </div>
            </>
          )}
        </CardContent>
      </Card>

      <div className="flex justify-center mt-4">
        <Button
          variant="ghost"
          size="icon"
          onClick={handleFlip}
          className="text-muted-foreground hover:text-primary"
        >
          <RotateCcw className="w-5 h-5" />
        </Button>
      </div>
    </div>
  );
};

export default StudyCard;