import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { CheckCircle, XCircle, Volume2, Image } from 'lucide-react';

interface CardOption {
  id: string;
  option_text: string;
  is_correct: boolean;
  order_position: number;
}

interface MultipleChoiceCardProps {
  front: string;
  back: string;
  options: CardOption[];
  example?: string;
  hasAudio?: boolean;
  hasImage?: boolean;
  onAnswer: (isCorrect: boolean, responseTime: number) => void;
}

export const MultipleChoiceCard = ({
  front,
  back,
  options,
  example,
  hasAudio,
  hasImage,
  onAnswer
}: MultipleChoiceCardProps) => {
  const [startTime] = useState(Date.now());
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [isCorrect, setIsCorrect] = useState(false);

  const sortedOptions = [...options].sort((a, b) => a.order_position - b.order_position);

  const handleOptionSelect = (optionId: string) => {
    if (showResult) return;
    
    const responseTime = Date.now() - startTime;
    const selectedOptionData = options.find(opt => opt.id === optionId);
    const correct = selectedOptionData?.is_correct || false;
    
    setSelectedOption(optionId);
    setIsCorrect(correct);
    setShowResult(true);
    
    // Call onAnswer after a brief delay to show the result
    setTimeout(() => {
      onAnswer(correct, responseTime);
    }, 2000);
  };

  const getOptionStyle = (option: CardOption) => {
    if (!showResult) {
      return selectedOption === option.id
        ? "border-primary bg-primary/10"
        : "border-border hover:border-primary/50";
    }

    if (option.is_correct) {
      return "border-green-500 bg-green-50 text-green-700";
    }

    if (selectedOption === option.id && !option.is_correct) {
      return "border-red-500 bg-red-50 text-red-700";
    }

    return "border-border bg-muted/30";
  };

  return (
    <Card className="w-full max-w-2xl mx-auto shadow-lg">
      <CardHeader className="text-center">
        <CardTitle className="text-xl font-semibold flex items-center justify-center gap-2">
          {front}
          {hasAudio && <Volume2 className="w-5 h-5 text-primary" />}
          {hasImage && <Image className="w-5 h-5 text-primary" />}
        </CardTitle>
      </CardHeader>
      
      <CardContent className="space-y-4">
        {showResult && (
          <div className="text-center p-4 rounded-lg bg-muted/50">
            <p className="font-medium mb-2">{back}</p>
            {example && (
              <p className="text-sm text-muted-foreground italic">
                Example: {example}
              </p>
            )}
          </div>
        )}

        <div className="space-y-3">
          {sortedOptions.map((option, index) => (
            <Button
              key={option.id}
              variant="outline"
              size="lg"
              className={`w-full justify-start text-left h-auto p-4 ${getOptionStyle(option)}`}
              onClick={() => handleOptionSelect(option.id)}
              disabled={showResult}
            >
              <div className="flex items-center gap-3 w-full">
                <Badge variant="secondary" className="shrink-0">
                  {String.fromCharCode(65 + index)}
                </Badge>
                <span className="flex-1">{option.option_text}</span>
                {showResult && option.is_correct && (
                  <CheckCircle className="w-5 h-5 text-green-600" />
                )}
                {showResult && selectedOption === option.id && !option.is_correct && (
                  <XCircle className="w-5 h-5 text-red-600" />
                )}
              </div>
            </Button>
          ))}
        </div>

        {showResult && (
          <div className="text-center pt-4">
            <Badge variant={isCorrect ? "default" : "destructive"} className="text-lg px-4 py-2">
              {isCorrect ? "Correct!" : "Incorrect"}
            </Badge>
          </div>
        )}
      </CardContent>
    </Card>
  );
};