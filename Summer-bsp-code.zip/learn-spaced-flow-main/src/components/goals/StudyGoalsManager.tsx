import { useState, useEffect } from 'react';
import { Plus, Target, Clock, Flame, Edit, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface StudyGoal {
  id: string;
  goal_type: 'daily_cards' | 'daily_time' | 'streak';
  target_value: number;
  current_value: number;
  target_date: string | null;
  is_active: boolean;
  created_at: string;
}

interface NewGoal {
  goal_type: 'daily_cards' | 'daily_time' | 'streak';
  target_value: number;
  target_date?: string;
}

export const StudyGoalsManager = () => {
  const [goals, setGoals] = useState<StudyGoal[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [newGoal, setNewGoal] = useState<NewGoal>({
    goal_type: 'daily_cards',
    target_value: 20
  });

  useEffect(() => {
    fetchGoals();
  }, []);

  const fetchGoals = async () => {
    try {
      const { data, error } = await supabase
        .from('study_goals')
        .select('*')
        .eq('user_id', 'temp-user-id') // TODO: Replace with actual user ID
        .eq('is_active', true)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setGoals((data || []) as StudyGoal[]);
    } catch (error) {
      console.error('Error fetching goals:', error);
      toast.error('Failed to load study goals');
    } finally {
      setLoading(false);
    }
  };

  const createGoal = async () => {
    try {
      const { error } = await supabase
        .from('study_goals')
        .insert({
          user_id: 'temp-user-id', // TODO: Replace with actual user ID
          ...newGoal
        });

      if (error) throw error;

      toast.success('Study goal created!');
      setDialogOpen(false);
      setNewGoal({ goal_type: 'daily_cards', target_value: 20 });
      fetchGoals();
    } catch (error) {
      console.error('Error creating goal:', error);
      toast.error('Failed to create goal');
    }
  };

  const deleteGoal = async (goalId: string) => {
    try {
      const { error } = await supabase
        .from('study_goals')
        .update({ is_active: false })
        .eq('id', goalId);

      if (error) throw error;

      toast.success('Goal removed');
      fetchGoals();
    } catch (error) {
      console.error('Error deleting goal:', error);
      toast.error('Failed to remove goal');
    }
  };

  const getGoalIcon = (type: string) => {
    switch (type) {
      case 'daily_cards':
        return <Target className="w-5 h-5" />;
      case 'daily_time':
        return <Clock className="w-5 h-5" />;
      case 'streak':
        return <Flame className="w-5 h-5" />;
      default:
        return <Target className="w-5 h-5" />;
    }
  };

  const getGoalLabel = (type: string) => {
    switch (type) {
      case 'daily_cards':
        return 'Daily Cards';
      case 'daily_time':
        return 'Daily Time (minutes)';
      case 'streak':
        return 'Study Streak (days)';
      default:
        return 'Unknown Goal';
    }
  };

  const getProgressPercentage = (goal: StudyGoal) => {
    return Math.min(100, Math.round((goal.current_value / goal.target_value) * 100));
  };

  if (loading) {
    return (
      <div className="space-y-4">
        {[1, 2, 3].map((i) => (
          <Card key={i} className="animate-pulse">
            <CardHeader>
              <div className="h-6 bg-muted rounded w-1/3"></div>
            </CardHeader>
            <CardContent>
              <div className="h-4 bg-muted rounded w-full"></div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Study Goals</h2>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              Add Goal
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Create New Study Goal</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="goal-type">Goal Type</Label>
                <Select
                  value={newGoal.goal_type}
                  onValueChange={(value: 'daily_cards' | 'daily_time' | 'streak') =>
                    setNewGoal({ ...newGoal, goal_type: value })
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="daily_cards">Daily Cards Target</SelectItem>
                    <SelectItem value="daily_time">Daily Time Target</SelectItem>
                    <SelectItem value="streak">Study Streak</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="target-value">Target Value</Label>
                <Input
                  id="target-value"
                  type="number"
                  value={newGoal.target_value}
                  onChange={(e) =>
                    setNewGoal({ ...newGoal, target_value: parseInt(e.target.value) || 0 })
                  }
                  placeholder="Enter target value"
                />
              </div>
              <div>
                <Label htmlFor="target-date">Target Date (Optional)</Label>
                <Input
                  id="target-date"
                  type="date"
                  value={newGoal.target_date || ''}
                  onChange={(e) =>
                    setNewGoal({ ...newGoal, target_date: e.target.value || undefined })
                  }
                />
              </div>
              <Button onClick={createGoal} className="w-full">
                Create Goal
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {goals.length === 0 ? (
        <Card>
          <CardContent className="text-center py-8">
            <Target className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
            <h3 className="text-lg font-semibold mb-2">No Study Goals Yet</h3>
            <p className="text-muted-foreground mb-4">
              Set your first study goal to stay motivated and track your progress!
            </p>
            <Button onClick={() => setDialogOpen(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Create Your First Goal
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {goals.map((goal) => (
            <Card key={goal.id}>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium flex items-center gap-2">
                  {getGoalIcon(goal.goal_type)}
                  {getGoalLabel(goal.goal_type)}
                </CardTitle>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => deleteGoal(goal.id)}
                  className="h-8 w-8 p-0 hover:bg-destructive/10"
                >
                  <Trash2 className="w-4 h-4 text-destructive" />
                </Button>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between text-sm">
                    <span>Progress</span>
                    <span className="font-medium">
                      {goal.current_value} / {goal.target_value}
                    </span>
                  </div>
                  <Progress value={getProgressPercentage(goal)} className="h-2" />
                  <Badge
                    variant={getProgressPercentage(goal) >= 100 ? "default" : "secondary"}
                    className="w-full justify-center"
                  >
                    {getProgressPercentage(goal)}% Complete
                  </Badge>
                  {goal.target_date && (
                    <p className="text-xs text-muted-foreground">
                      Target: {new Date(goal.target_date).toLocaleDateString()}
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
};

export default StudyGoalsManager;