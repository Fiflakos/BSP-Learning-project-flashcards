import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Loader2, Sparkles } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

export function AIDeckGenerator() {
  const [prompt, setPrompt] = useState('');
  const [deckName, setDeckName] = useState('');
  const [deckDescription, setDeckDescription] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const { toast } = useToast();

  const handleGenerate = async () => {
    if (!prompt.trim()) {
      toast({
        title: "Error",
        description: "Please enter a prompt to generate flashcards.",
        variant: "destructive",
      });
      return;
    }

    setIsGenerating(true);
    
    try {
      const { data, error } = await supabase.functions.invoke('generate-deck-ai', {
        body: {
          prompt: prompt.trim(),
          deckName: deckName.trim() || undefined,
          deckDescription: deckDescription.trim() || undefined,
        },
      });

      if (error) {
        console.error('Error calling generate-deck-ai:', error);
        throw new Error(error.message || 'Failed to generate deck');
      }

      if (data.error) {
        throw new Error(data.error);
      }

      toast({
        title: "Success!",
        description: data.message || "Deck generated successfully!",
      });

      
      setPrompt('');
      setDeckName('');
      setDeckDescription('');

    } catch (error) {
      console.error('Error generating deck:', error);
      toast({
        title: "Error",
        description: error.message || "Failed to generate deck. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Sparkles className="h-5 w-5 text-primary" />
          AI Deck Generator
        </CardTitle>
        <CardDescription>
          Generate flashcard decks using AI. Describe what you want to learn and let AI create the cards for you.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="prompt">Learning Topic or Prompt *</Label>
          <Textarea
            id="prompt"
            placeholder="e.g., 'Basic Spanish vocabulary for travel', 'JavaScript array methods', 'World capitals in Europe'"
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            className="min-h-[100px]"
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="deckName">Deck Name (optional)</Label>
            <Input
              id="deckName"
              placeholder="Leave empty for auto-generated name"
              value={deckName}
              onChange={(e) => setDeckName(e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="deckDescription">Description (optional)</Label>
            <Input
              id="deckDescription"
              placeholder="Brief description of the deck"
              value={deckDescription}
              onChange={(e) => setDeckDescription(e.target.value)}
            />
          </div>
        </div>

        <Button 
          onClick={handleGenerate} 
          disabled={isGenerating || !prompt.trim()}
          className="w-full"
        >
          {isGenerating ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Generating Cards...
            </>
          ) : (
            <>
              <Sparkles className="mr-2 h-4 w-4" />
              Generate Flashcards with AI
            </>
          )}
        </Button>

        <div className="text-sm text-muted-foreground">
          <p>💡 <strong>Tips for better results:</strong></p>
          <ul className="list-disc list-inside mt-1 space-y-1">
            <li>Be specific about the topic and difficulty level</li>
            <li>Mention the format you prefer (e.g., "question-answer", "term-definition")</li>
            <li>Include context like "for beginners" or "advanced level"</li>
          </ul>
        </div>
      </CardContent>
    </Card>
  );
}