import { useState, useEffect } from "react";
import { useSearchParams, useNavigate } from "react-router-dom";
import Header from "@/components/layout/Header";
import StudyCard from "@/components/study/StudyCard";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowLeft, SkipForward, Settings } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

interface StudyCard {
  id: string;
  front: string;
  back: string;
  example: string | null;
  has_audio: boolean;
  has_image: boolean;
}

interface Deck {
  id: string;
  name: string;
  description: string | null;
}

const Study = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  
  const [deck, setDeck] = useState<Deck | null>(null);
  const [cards, setCards] = useState<StudyCard[]>([]);
  const [currentCard, setCurrentCard] = useState(0);
  const [sessionProgress, setSessionProgress] = useState(0);
  const [loading, setLoading] = useState(true);
  
  const deckId = searchParams.get('deck');

  useEffect(() => {
    if (deckId) {
      fetchStudyData();
    } else {
      // No deck specified, load a random deck or show deck selection
      fetchRandomDeck();
    }
  }, [deckId]);

  const fetchStudyData = async () => {
    try {
      // Fetch deck info
      const { data: deckData, error: deckError } = await (supabase as any)
        .from('decks')
        .select('*')
        .eq('id', deckId)
        .single();

      if (deckError) {
        console.error('Error fetching deck:', deckError);
        toast({
          title: "Error",
          description: "Deck not found",
          variant: "destructive"
        });
        navigate('/decks');
        return;
      }

      setDeck(deckData);

      // Fetch cards
      const { data: cardsData, error: cardsError } = await (supabase as any)
        .from('cards')
        .select('*')
        .eq('deck_id', deckId)
        .order('created_at', { ascending: false });

      if (cardsError) {
        console.error('Error fetching cards:', cardsError);
        setCards([]);
      } else {
        setCards(cardsData || []);
      }
    } catch (error) {
      console.error('Error:', error);
      toast({
        title: "Error",
        description: "Failed to load study data",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchRandomDeck = async () => {
    try {
      // Fetch first available deck
      const { data: decksData, error: decksError } = await (supabase as any)
        .from('decks')
        .select('*')
        .limit(1);

      if (decksError || !decksData || decksData.length === 0) {
        setLoading(false);
        return;
      }

      const firstDeck = decksData[0];
      setDeck(firstDeck);

      // Fetch cards for this deck
      const { data: cardsData, error: cardsError } = await (supabase as any)
        .from('cards')
        .select('*')
        .eq('deck_id', firstDeck.id)
        .order('created_at', { ascending: false });

      if (!cardsError) {
        setCards(cardsData || []);
      }
    } catch (error) {
      console.error('Error:', error);
    } finally {
      setLoading(false);
    }
  };

  const totalCards = cards.length;
  const progressPercentage = totalCards > 0 ? (sessionProgress / totalCards) * 100 : 0;

  const handleRate = (difficulty: 'again' | 'hard' | 'good' | 'easy') => {
    console.log(`Rated: ${difficulty}`);
    // Move to next card
    if (currentCard < cards.length - 1) {
      setCurrentCard(currentCard + 1);
      setSessionProgress(sessionProgress + 1);
    }
  };

  const handleSkip = () => {
    if (currentCard < cards.length - 1) {
      setCurrentCard(currentCard + 1);
    }
  };

  const handleGoBack = () => {
    navigate('/decks');
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="container mx-auto px-4 py-8">
          <div className="text-center">Loading study session...</div>
        </div>
      </div>
    );
  }

  if (!deck || cards.length === 0) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="container mx-auto px-4 py-8">
          <div className="text-center space-y-4">
            <h2 className="text-2xl font-bold">No Cards Available</h2>
            <p className="text-muted-foreground">
              {!deck ? "No deck found" : "This deck doesn't have any cards yet"}
            </p>
            <div className="flex gap-2 justify-center">
              <Button onClick={() => navigate('/decks')}>
                Browse Decks
              </Button>
              {deck && (
                <Button variant="outline" onClick={() => navigate(`/decks/${deck.id}/cards`)}>
                  Add Cards
                </Button>
              )}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container mx-auto px-4 py-8">
        {/* Study Session Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={handleGoBack}>
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="text-2xl font-bold text-foreground">{deck.name}</h1>
              <p className="text-muted-foreground">Study Session</p>
            </div>
          </div>
          
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon">
              <Settings className="w-5 h-5" />
            </Button>
            <Button variant="ghost" size="icon" onClick={handleSkip}>
              <SkipForward className="w-5 h-5" />
            </Button>
          </div>
        </div>

        {/* Progress Bar */}
        <Card className="mb-8 bg-gradient-card border-border/50">
          <CardContent className="p-6">
            <div className="space-y-3">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Session Progress</span>
                <span className="text-primary font-medium">{sessionProgress}/{totalCards} cards</span>
              </div>
              <Progress value={progressPercentage} className="h-2" />
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>Started 5 minutes ago</span>
                <span>~{Math.round((totalCards - sessionProgress) * 0.8)} min remaining</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Study Card */}
        <div className="flex justify-center">
          {currentCard < cards.length ? (
            <StudyCard
              front={cards[currentCard].front}
              back={cards[currentCard].back}
              example={cards[currentCard].example}
              hasAudio={cards[currentCard].has_audio}
              hasImage={cards[currentCard].has_image}
              onRate={handleRate}
            />
          ) : (
            <Card className="w-full max-w-lg text-center p-8">
              <CardContent>
                <div className="text-6xl mb-4">🎉</div>
                <h2 className="text-2xl font-bold mb-2">Session Complete!</h2>
                <p className="text-muted-foreground mb-4">
                  Great job! You've reviewed all cards in this deck.
                </p>
                <div className="flex gap-2 justify-center">
                  <Button onClick={() => { setCurrentCard(0); setSessionProgress(0); }}>
                    Study Again
                  </Button>
                  <Button variant="outline" onClick={() => navigate('/decks')}>
                    Back to Decks
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Session Stats */}
        <div className="mt-8 grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card className="bg-gradient-card border-border/50">
            <CardContent className="p-4 text-center">
              <p className="text-2xl font-bold text-success">8</p>
              <p className="text-xs text-muted-foreground">Easy</p>
            </CardContent>
          </Card>
          <Card className="bg-gradient-card border-border/50">
            <CardContent className="p-4 text-center">
              <p className="text-2xl font-bold text-primary">3</p>
              <p className="text-xs text-muted-foreground">Good</p>
            </CardContent>
          </Card>
          <Card className="bg-gradient-card border-border/50">
            <CardContent className="p-4 text-center">
              <p className="text-2xl font-bold text-warning">1</p>
              <p className="text-xs text-muted-foreground">Hard</p>
            </CardContent>
          </Card>
          <Card className="bg-gradient-card border-border/50">
            <CardContent className="p-4 text-center">
              <p className="text-2xl font-bold text-destructive">0</p>
              <p className="text-xs text-muted-foreground">Again</p>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
};

export default Study;