import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import PerformanceAnalytics from '@/components/analytics/PerformanceAnalytics';
import StudyGoalsManager from '@/components/goals/StudyGoalsManager';
import Header from '@/components/layout/Header';

const Progress = () => {
  return (
    <div className="min-h-screen bg-gradient-subtle">
      <Header />
      <main className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-foreground mb-2">Your Progress</h1>
          <p className="text-xl text-muted-foreground">
            Track your learning journey and achievements
          </p>
        </div>

        <Tabs defaultValue="analytics" className="space-y-6">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="analytics">Performance Analytics</TabsTrigger>
            <TabsTrigger value="goals">Study Goals</TabsTrigger>
          </TabsList>

          <TabsContent value="analytics" className="space-y-6">
            <PerformanceAnalytics />
          </TabsContent>

          <TabsContent value="goals" className="space-y-6">
            <StudyGoalsManager />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
};

export default Progress;