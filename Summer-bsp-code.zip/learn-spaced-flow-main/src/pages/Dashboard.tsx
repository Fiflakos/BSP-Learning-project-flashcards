import { useState, useEffect } from "react";
import Header from "@/components/layout/Header";
import StatCard from "@/components/dashboard/StatCard";
import ProgressChart from "@/components/dashboard/ProgressChart";
import QuickActions from "@/components/dashboard/QuickActions";
import { AIDeckGenerator } from "@/components/ai/AIDeckGenerator";
import { Brain, Calendar, TrendingUp, Clock, Target, Zap, BookOpen } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

interface DashboardStats {
  totalDecks: number;
  totalCards: number;
  cardsDueToday: number;
  recentlyStudied: number;
}

const Dashboard = () => {
  const [stats, setStats] = useState<DashboardStats>({
    totalDecks: 0,
    totalCards: 0,
    cardsDueToday: 0,
    recentlyStudied: 0
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDashboardStats();
  }, []);

  const fetchDashboardStats = async () => {
    try {
      // Fetch decks count
      const { data: decksData, error: decksError } = await (supabase as any)
        .from('decks')
        .select('id');

      // Fetch cards count
      const { data: cardsData, error: cardsError } = await (supabase as any)
        .from('cards')
        .select('id');

      // Calculate cards due today (simplified - using created_at for demo)
      const { data: cardsDueData, error: cardsDueError } = await (supabase as any)
        .from('cards')
        .select('id')
        .gte('created_at', new Date().toISOString().split('T')[0]);

      if (!decksError && !cardsError) {
        setStats({
          totalDecks: decksData?.length || 0,
          totalCards: cardsData?.length || 0,
          cardsDueToday: cardsDueData?.length || 0,
          recentlyStudied: Math.floor((cardsData?.length || 0) * 0.3) // Simplified calculation
        });
      }
    } catch (error) {
      console.error('Error fetching dashboard stats:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="container mx-auto px-4 py-8">
          <div className="text-center">Loading dashboard...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container mx-auto px-4 py-8 space-y-8">
        {/* Welcome Section */}
        <div className="space-y-2">
          <h1 className="text-3xl font-bold text-foreground">
            Welcome back, Scholar! 
          </h1>
          <p className="text-muted-foreground">
            {stats.totalDecks === 0 
              ? "Create your first deck to start learning!"
              : `Ready to expand your knowledge? You have ${stats.cardsDueToday} cards to review today.`
            }
          </p>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <StatCard
            title="Total Decks"
            value={stats.totalDecks}
            description={stats.totalDecks === 0 ? "Create your first deck" : "Active collections"}
            icon={<BookOpen className="w-6 h-6 text-primary" />}
            trend={stats.totalDecks > 0 ? "up" : "neutral"}
          />
          <StatCard
            title="Total Cards"
            value={stats.totalCards}
            description={stats.totalCards === 0 ? "Add some flashcards" : "Ready to study"}
            icon={<Brain className="w-6 h-6 text-success" />}
            trend={stats.totalCards > 0 ? "up" : "neutral"}
          />
          <StatCard
            title="Cards Due Today"
            value={stats.cardsDueToday}
            description={stats.cardsDueToday === 0 ? "All caught up!" : "Let's get started"}
            icon={<Calendar className="w-6 h-6 text-accent" />}
            trend={stats.cardsDueToday > 0 ? "up" : "neutral"}
          />
          {stats.totalCards > 0 && (
            <>
              <StatCard
                title="Recently Studied"
                value={stats.recentlyStudied}
                description="Keep up the momentum"
                icon={<Clock className="w-6 h-6 text-warning" />}
                trend="up"
              />
              <StatCard
                title="Study Progress"
                value={`${Math.round((stats.recentlyStudied / stats.totalCards) * 100)}%`}
                description="Of total cards reviewed"
                icon={<Target className="w-6 h-6 text-primary" />}
                trend="up"
              />
              <StatCard
                title="Collection Health"
                value="Growing"
                description="Add more content to learn"
                icon={<TrendingUp className="w-6 h-6 text-success" />}
                trend="up"
              />
            </>
          )}
        </div>

        {/* AI Deck Generator */}
        <AIDeckGenerator />

        {/* Progress Chart - Only show if user has cards */}
        {stats.totalCards > 0 && <ProgressChart />}

        {/* Quick Actions */}
        <QuickActions />
      </main>
    </div>
  );
};

export default Dashboard;