import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Plus, Edit, Trash2, ArrowLeft, Upload, Download } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import Header from "@/components/layout/Header";

interface Card {
  id: string;
  front: string;
  back: string;
  example: string | null;
  has_audio: boolean;
  has_image: boolean;
  created_at: string;
}

interface Deck {
  id: string;
  name: string;
  description: string | null;
}

const DeckCards = () => {
  const { deckId } = useParams<{ deckId: string }>();
  const navigate = useNavigate();
  const [deck, setDeck] = useState<Deck | null>(null);
  const [cards, setCards] = useState<Card[]>([]);
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [editingCard, setEditingCard] = useState<Card | null>(null);
  const [formData, setFormData] = useState({
    front: "",
    back: "",
    example: "",
    has_audio: false,
    has_image: false
  });
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    if (deckId) {
      fetchDeckAndCards();
    }
  }, [deckId]);

  const fetchDeckAndCards = async () => {
    try {
      // Fetch deck info
      const { data: deckData, error: deckError } = await (supabase as any)
        .from('decks')
        .select('*')
        .eq('id', deckId)
        .single();

      if (deckError) {
        console.error('Error fetching deck:', deckError);
        toast({
          title: "Error",
          description: "Deck not found or access denied",
          variant: "destructive"
        });
        navigate('/decks');
        return;
      }

      setDeck(deckData);

      // Fetch cards
      const { data: cardsData, error: cardsError } = await (supabase as any)
        .from('cards')
        .select('*')
        .eq('deck_id', deckId)
        .order('created_at', { ascending: false });

      if (cardsError) {
        console.error('Error fetching cards:', cardsError);
        setCards([]);
      } else {
        setCards(cardsData || []);
      }
    } catch (error) {
      console.error('Error:', error);
      toast({
        title: "Error",
        description: "Failed to load deck data",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      if (editingCard) {
        // Update existing card
        const { error } = await (supabase as any)
          .from('cards')
          .update({
            front: formData.front,
            back: formData.back,
            example: formData.example || null,
            has_audio: formData.has_audio,
            has_image: formData.has_image
          })
          .eq('id', editingCard.id);

        if (error) throw error;
        
        toast({
          title: "Success",
          description: "Card updated successfully",
        });
      } else {
        // Create new card
        const { error } = await (supabase as any)
          .from('cards')
          .insert({
            deck_id: deckId,
            front: formData.front,
            back: formData.back,
            example: formData.example || null,
            has_audio: formData.has_audio,
            has_image: formData.has_image
          });

        if (error) throw error;
        
        toast({
          title: "Success",
          description: "Card created successfully",
        });
      }
      
      fetchDeckAndCards();
      handleCloseDialog();
    } catch (error) {
      console.error('Error saving card:', error);
      toast({
        title: "Error",
        description: "Failed to save card. Please try again.",
        variant: "destructive"
      });
    }
  };

  const handleDelete = async (card: Card) => {
    try {
      const { error } = await (supabase as any)
        .from('cards')
        .delete()
        .eq('id', card.id);

      if (error) throw error;
      
      toast({
        title: "Success",
        description: "Card deleted successfully",
      });
      
      fetchDeckAndCards();
    } catch (error) {
      console.error('Error deleting card:', error);
      toast({
        title: "Error",
        description: "Failed to delete card",
        variant: "destructive"
      });
    }
  };

  const handleCloseDialog = () => {
    setIsCreateOpen(false);
    setEditingCard(null);
    setFormData({
      front: "",
      back: "",
      example: "",
      has_audio: false,
      has_image: false
    });
  };

  const openEditDialog = (card: Card) => {
    setEditingCard(card);
    setFormData({
      front: card.front,
      back: card.back,
      example: card.example || "",
      has_audio: card.has_audio,
      has_image: card.has_image
    });
  };

  const handleBulkImport = () => {
    toast({
      title: "Coming Soon",
      description: "Bulk import feature will be available soon",
    });
  };

  const handleExport = () => {
    if (cards.length === 0) {
      toast({
        title: "No Cards",
        description: "No cards to export",
        variant: "destructive"
      });
      return;
    }

    // Simple CSV export
    const csvContent = [
      "Front,Back,Example",
      ...cards.map(card => 
        `"${card.front}","${card.back}","${card.example || ""}"`
      )
    ].join("\n");

    const blob = new Blob([csvContent], { type: "text/csv" });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${deck?.name || 'deck'}-cards.csv`;
    a.click();
    window.URL.revokeObjectURL(url);

    toast({
      title: "Success",
      description: "Cards exported successfully",
    });
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="container mx-auto px-4 py-8">
          <div className="text-center">Loading cards...</div>
        </div>
      </div>
    );
  }

  if (!deck) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="container mx-auto px-4 py-8">
          <div className="text-center">Deck not found</div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <Button variant="ghost" size="icon" onClick={() => navigate('/decks')}>
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div className="flex-1">
            <h1 className="text-3xl font-bold text-foreground">{deck.name}</h1>
            {deck.description && (
              <p className="text-muted-foreground mt-1">{deck.description}</p>
            )}
            <p className="text-sm text-muted-foreground mt-1">
              {cards.length} {cards.length === 1 ? 'card' : 'cards'}
            </p>
          </div>
          
          <div className="flex gap-2">
            <Button variant="outline" onClick={handleBulkImport}>
              <Upload className="w-4 h-4 mr-2" />
              Import
            </Button>
            <Button variant="outline" onClick={handleExport}>
              <Download className="w-4 h-4 mr-2" />
              Export
            </Button>
            <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="w-4 h-4 mr-2" />
                  Add Card
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-md">
                <DialogHeader>
                  <DialogTitle>Add New Card</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <Label htmlFor="front">Front</Label>
                    <Input
                      id="front"
                      value={formData.front}
                      onChange={(e) => setFormData({ ...formData, front: e.target.value })}
                      placeholder="Enter front of card"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="back">Back</Label>
                    <Textarea
                      id="back"
                      value={formData.back}
                      onChange={(e) => setFormData({ ...formData, back: e.target.value })}
                      placeholder="Enter back of card"
                      rows={3}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="example">Example (Optional)</Label>
                    <Textarea
                      id="example"
                      value={formData.example}
                      onChange={(e) => setFormData({ ...formData, example: e.target.value })}
                      placeholder="Enter usage example"
                      rows={2}
                    />
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch
                      id="has_audio"
                      checked={formData.has_audio}
                      onCheckedChange={(checked) => setFormData({ ...formData, has_audio: checked })}
                    />
                    <Label htmlFor="has_audio">Has Audio</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch
                      id="has_image"
                      checked={formData.has_image}
                      onCheckedChange={(checked) => setFormData({ ...formData, has_image: checked })}
                    />
                    <Label htmlFor="has_image">Has Image</Label>
                  </div>
                  <div className="flex gap-2 justify-end">
                    <Button type="button" variant="outline" onClick={handleCloseDialog}>
                      Cancel
                    </Button>
                    <Button type="submit">Add Card</Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        {/* Edit Dialog */}
        <Dialog open={!!editingCard} onOpenChange={() => setEditingCard(null)}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Edit Card</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="edit-front">Front</Label>
                <Input
                  id="edit-front"
                  value={formData.front}
                  onChange={(e) => setFormData({ ...formData, front: e.target.value })}
                  placeholder="Enter front of card"
                  required
                />
              </div>
              <div>
                <Label htmlFor="edit-back">Back</Label>
                <Textarea
                  id="edit-back"
                  value={formData.back}
                  onChange={(e) => setFormData({ ...formData, back: e.target.value })}
                  placeholder="Enter back of card"
                  rows={3}
                  required
                />
              </div>
              <div>
                <Label htmlFor="edit-example">Example (Optional)</Label>
                <Textarea
                  id="edit-example"
                  value={formData.example}
                  onChange={(e) => setFormData({ ...formData, example: e.target.value })}
                  placeholder="Enter usage example"
                  rows={2}
                />
              </div>
              <div className="flex items-center space-x-2">
                <Switch
                  id="edit-has_audio"
                  checked={formData.has_audio}
                  onCheckedChange={(checked) => setFormData({ ...formData, has_audio: checked })}
                />
                <Label htmlFor="edit-has_audio">Has Audio</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Switch
                  id="edit-has_image"
                  checked={formData.has_image}
                  onCheckedChange={(checked) => setFormData({ ...formData, has_image: checked })}
                />
                <Label htmlFor="edit-has_image">Has Image</Label>
              </div>
              <div className="flex gap-2 justify-end">
                <Button type="button" variant="outline" onClick={handleCloseDialog}>
                  Cancel
                </Button>
                <Button type="submit">Update Card</Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>

        {/* Cards Grid */}
        {cards.length === 0 ? (
          <Card className="text-center py-12">
            <CardContent>
              <div className="text-6xl mb-4">📚</div>
              <h3 className="text-lg font-semibold mb-2">No cards yet</h3>
              <p className="text-muted-foreground mb-4">
                Add your first flashcard to start learning
              </p>
              <Button onClick={() => setIsCreateOpen(true)}>
                <Plus className="w-4 h-4 mr-2" />
                Add Your First Card
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {cards.map((card) => (
              <Card key={card.id} className="hover:shadow-card-hover transition-shadow">
                <CardHeader className="pb-2">
                  <div className="flex items-center justify-between">
                    <div className="flex gap-1">
                      {card.has_audio && <span className="text-xs bg-primary/10 text-primary px-2 py-1 rounded">Audio</span>}
                      {card.has_image && <span className="text-xs bg-accent/10 text-accent px-2 py-1 rounded">Image</span>}
                    </div>
                    <div className="flex gap-1">
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className="h-8 w-8"
                        onClick={() => openEditDialog(card)}
                      >
                        <Edit className="w-4 h-4" />
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className="h-8 w-8 text-destructive hover:text-destructive"
                        onClick={() => handleDelete(card)}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                
                <CardContent className="space-y-3">
                  <div>
                    <p className="text-sm text-muted-foreground">Front:</p>
                    <p className="font-medium">{card.front}</p>
                  </div>
                  
                  <div>
                    <p className="text-sm text-muted-foreground">Back:</p>
                    <p className="text-sm">{card.back}</p>
                  </div>
                  
                  {card.example && (
                    <div>
                      <p className="text-sm text-muted-foreground">Example:</p>
                      <p className="text-sm italic">{card.example}</p>
                    </div>
                  )}
                  
                  <div className="text-xs text-muted-foreground">
                    Created {new Date(card.created_at).toLocaleDateString()}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </main>
    </div>
  );
};

export default DeckCards;