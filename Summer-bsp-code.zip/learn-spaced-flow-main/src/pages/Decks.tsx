import { useState, useEffect } from "react";
import { Plus, Edit, Trash2, BookOpen, MoreVertical } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import Header from "@/components/layout/Header";
import { useNavigate } from "react-router-dom";

interface Deck {
  id: string;
  name: string;
  description: string | null;
  created_at: string;
  card_count?: number;
}

const Decks = () => {
  const navigate = useNavigate();
  const [decks, setDecks] = useState<Deck[]>([]);
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [editingDeck, setEditingDeck] = useState<Deck | null>(null);
  const [formData, setFormData] = useState({ name: "", description: "" });
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    fetchDecks();
  }, []);

  const fetchDecks = async () => {
    try {
      // For now, we'll fetch without user authentication
      const { data, error } = await (supabase as any)
        .from('decks')
        .select(`
          *,
          cards(count)
        `);

      if (error) {
        console.error('Error fetching decks:', error);
        setDecks([]);
      } else {
        const decksWithCount = data?.map((deck: any) => ({
          ...deck,
          card_count: deck.cards?.length || 0
        })) || [];
        setDecks(decksWithCount);
      }
    } catch (error) {
      console.error('Error:', error);
      setDecks([]);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      if (editingDeck) {
        // Update existing deck
        const { error } = await (supabase as any)
          .from('decks')
          .update({
            name: formData.name,
            description: formData.description || null
          })
          .eq('id', editingDeck.id);

        if (error) throw error;
        
        toast({
          title: "Success",
          description: "Deck updated successfully",
        });
      } else {
        // Create new deck - for now without user_id since no auth
        const { error } = await (supabase as any)
          .from('decks')
          .insert({
            name: formData.name,
            description: formData.description || null,
            user_id: '00000000-0000-0000-0000-000000000000' // Temporary placeholder
          });

        if (error) throw error;
        
        toast({
          title: "Success",
          description: "Deck created successfully",
        });
      }
      
      fetchDecks();
      handleCloseDialog();
    } catch (error) {
      console.error('Error saving deck:', error);
      toast({
        title: "Error",
        description: "Failed to save deck. Authentication required.",
        variant: "destructive"
      });
    }
  };

  const handleDelete = async (deck: Deck) => {
    try {
      const { error } = await (supabase as any)
        .from('decks')
        .delete()
        .eq('id', deck.id);

      if (error) throw error;
      
      toast({
        title: "Success",
        description: "Deck deleted successfully",
      });
      
      fetchDecks();
    } catch (error) {
      console.error('Error deleting deck:', error);
      toast({
        title: "Error",
        description: "Failed to delete deck",
        variant: "destructive"
      });
    }
  };

  const handleCloseDialog = () => {
    setIsCreateOpen(false);
    setEditingDeck(null);
    setFormData({ name: "", description: "" });
  };

  const openEditDialog = (deck: Deck) => {
    setEditingDeck(deck);
    setFormData({ name: deck.name, description: deck.description || "" });
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="container mx-auto px-4 py-8">
          <div className="text-center">Loading decks...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-foreground mb-2">My Decks</h1>
            <p className="text-muted-foreground">Manage your flashcard collections</p>
          </div>
          
          <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2">
                <Plus className="w-4 h-4" />
                Create Deck
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Create New Deck</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <Label htmlFor="name">Deck Name</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="Enter deck name"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="description">Description (Optional)</Label>
                  <Textarea
                    id="description"
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    placeholder="Enter deck description"
                    rows={3}
                  />
                </div>
                <div className="flex gap-2 justify-end">
                  <Button type="button" variant="outline" onClick={handleCloseDialog}>
                    Cancel
                  </Button>
                  <Button type="submit">Create Deck</Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {/* Edit Dialog */}
        <Dialog open={!!editingDeck} onOpenChange={() => setEditingDeck(null)}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Edit Deck</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="edit-name">Deck Name</Label>
                <Input
                  id="edit-name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Enter deck name"
                  required
                />
              </div>
              <div>
                <Label htmlFor="edit-description">Description (Optional)</Label>
                <Textarea
                  id="edit-description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Enter deck description"
                  rows={3}
                />
              </div>
              <div className="flex gap-2 justify-end">
                <Button type="button" variant="outline" onClick={handleCloseDialog}>
                  Cancel
                </Button>
                <Button type="submit">Update Deck</Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>

        {/* Decks Grid */}
        {decks.length === 0 ? (
          <Card className="text-center py-12">
            <CardContent>
              <BookOpen className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
              <h3 className="text-lg font-semibold mb-2">No decks yet</h3>
              <p className="text-muted-foreground mb-4">
                Create your first flashcard deck to get started
              </p>
              <Button onClick={() => setIsCreateOpen(true)}>
                <Plus className="w-4 h-4 mr-2" />
                Create Your First Deck
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {decks.map((deck) => (
              <Card key={deck.id} className="hover:shadow-card-hover transition-shadow">
                <CardHeader className="flex flex-row items-start justify-between space-y-0 pb-2">
                  <div className="flex-1">
                    <CardTitle className="text-lg font-semibold line-clamp-1">
                      {deck.name}
                    </CardTitle>
                    {deck.description && (
                      <p className="text-sm text-muted-foreground mt-1 line-clamp-2">
                        {deck.description}
                      </p>
                    )}
                  </div>
                  
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon" className="h-8 w-8">
                        <MoreVertical className="w-4 h-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={() => openEditDialog(deck)}>
                        <Edit className="w-4 h-4 mr-2" />
                        Edit
                      </DropdownMenuItem>
                      <DropdownMenuItem 
                        onClick={() => handleDelete(deck)}
                        className="text-destructive"
                      >
                        <Trash2 className="w-4 h-4 mr-2" />
                        Delete
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </CardHeader>
                
                <CardContent>
                  <div className="flex items-center justify-between text-sm text-muted-foreground">
                    <span>{deck.card_count || 0} cards</span>
                    <span>Created {new Date(deck.created_at).toLocaleDateString()}</span>
                  </div>
                  
                  <div className="flex gap-2 mt-4">
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="flex-1"
                      onClick={() => navigate(`/decks/${deck.id}/cards`)}
                    >
                      <Edit className="w-4 h-4 mr-2" />
                      Manage Cards
                    </Button>
                    <Button 
                      size="sm" 
                      className="flex-1"
                      onClick={() => navigate(`/study?deck=${deck.id}`)}
                    >
                      <BookOpen className="w-4 h-4 mr-2" />
                      Study
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </main>
    </div>
  );
};

export default Decks;