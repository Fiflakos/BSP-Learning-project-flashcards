import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { SpacedRepetitionEngine, ReviewResult } from '@/components/study/SpacedRepetitionEngine';
import { toast } from 'sonner';

export interface StudySessionStats {
  cardsStudied: number;
  cardsCorrect: number;
  averageResponseTime: number;
  sessionDuration: number;
}

export const useStudySession = (deckId: string | null) => {
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [startTime, setStartTime] = useState<Date | null>(null);
  const [stats, setStats] = useState<StudySessionStats>({
    cardsStudied: 0,
    cardsCorrect: 0,
    averageResponseTime: 0,
    sessionDuration: 0
  });

  const startSession = async (sessionType: 'regular' | 'review' | 'cram' = 'regular') => {
    if (!deckId) return null;

    try {
      const { data, error } = await supabase
        .from('study_sessions')
        .insert({
          user_id: 'temp-user-id',
          deck_id: deckId,
          session_type: sessionType,
          started_at: new Date().toISOString()
        })
        .select()
        .single();

      if (error) throw error;

      setSessionId(data.id);
      setStartTime(new Date());
      toast.success('Study session started!');
      return data.id;
    } catch (error) {
      console.error('Error starting study session:', error);
      toast.error('Failed to start study session');
      return null;
    }
  };

  const endSession = async () => {
    if (!sessionId || !startTime) return;

    try {
      const endTime = new Date();
      const sessionDuration = Math.round((endTime.getTime() - startTime.getTime()) / 1000);

      const { error } = await supabase
        .from('study_sessions')
        .update({
          ended_at: endTime.toISOString(),
          cards_studied: stats.cardsStudied,
          cards_correct: stats.cardsCorrect
        })
        .eq('id', sessionId);

      if (error) throw error;

      setStats(prev => ({ ...prev, sessionDuration }));
      toast.success(`Session completed! Studied ${stats.cardsStudied} cards in ${Math.round(sessionDuration / 60)} minutes`);
    } catch (error) {
      console.error('Error ending study session:', error);
      toast.error('Failed to save session data');
    }
  };

  const recordReview = async (result: ReviewResult) => {
    if (!sessionId) return;

    const reviewStartTime = Date.now() - result.responseTime;
    
    try {
      const { data: cardData, error: cardError } = await supabase
        .from('review_records')
        .select('ease_factor, interval_days, consecutive_correct')
        .eq('card_id', result.cardId)
        .order('created_at', { ascending: false })
        .limit(1)
        .maybeSingle();

      if (cardError && cardError.code !== 'PGRST116') {
        throw cardError;
      }

      const schedule = SpacedRepetitionEngine.calculateNextReview(
        cardData?.ease_factor || 2.5,
        cardData?.interval_days || 1,
        cardData?.consecutive_correct || 0,
        result.rating
      );

      const { error: reviewError } = await supabase
        .from('review_records')
        .insert({
          card_id: result.cardId,
          user_id: 'temp-user-id',
          session_id: sessionId,
          rating: result.rating,
          response_time_ms: result.responseTime,
          previous_rating: null,
          consecutive_correct: schedule.consecutiveCorrect,
          ease_factor: schedule.easeFactor,
          interval_days: schedule.interval,
          next_review_date: schedule.nextReviewDate.toISOString()
        });

      if (reviewError) throw reviewError;

      const { data: currentCard } = await supabase
        .from('cards')
        .select('times_reviewed')
        .eq('id', result.cardId)
        .single();

      const { error: cardUpdateError } = await supabase
        .from('cards')
        .update({
          times_reviewed: (currentCard?.times_reviewed || 0) + 1,
          last_reviewed: new Date().toISOString()
        })
        .eq('id', result.cardId);

      if (cardUpdateError) throw cardUpdateError;

      await supabase.rpc('calculate_card_difficulty', { card_uuid: result.cardId });

      setStats(prev => ({
        cardsStudied: prev.cardsStudied + 1,
        cardsCorrect: prev.cardsCorrect + (result.rating >= 3 ? 1 : 0),
        averageResponseTime: Math.round((prev.averageResponseTime * prev.cardsStudied + result.responseTime) / (prev.cardsStudied + 1)),
        sessionDuration: prev.sessionDuration
      }));

    } catch (error) {
      console.error('Error recording review:', error);
      toast.error('Failed to save review');
    }
  };

  return {
    sessionId,
    stats,
    startSession,
    endSession,
    recordReview
  };
};