import { createClient } from '@supabase/supabase-js';
import type { Database } from './types';

const SUPABASE_URL = "https://ezjfxqkgpurmpcofvtrk.supabase.co";
const SUPABASE_PUBLISHABLE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImV6amZ4cWtncHVybXBjb2Z2dHJrIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTQzODg1MjYsImV4cCI6MjA2OTk2NDUyNn0.Vqpi3a6TqtySVbyOI-m8-2z0kodbmE47VEEMlHwEP80";

export const supabase = createClient<Database>(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY, {
  auth: {
    storage: localStorage,
    persistSession: true,
    autoRefreshToken: true,
  }
});